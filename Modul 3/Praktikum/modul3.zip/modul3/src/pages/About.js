import React from "react";
import Navbar from "../components/Navbar";

function About() {
  return (
    <div>
      <Navbar />
      <h1>Halaman About</h1>
    </div>
  );
}

export default About;
