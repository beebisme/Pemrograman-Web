import React from "react";
import Navbar from "../components/Navbar";

function Contact() {
  return (
    <div>
      <Navbar />
      <h1>Halaman Contact</h1>
    </div>
  );
}

export default Contact;
